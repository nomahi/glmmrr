# glmmrr 2.1-1 (2025-09-24)

- Reference information is updated.

# glmmrr 1.1-1 (2025-01-10)

- first version released on GitHub
