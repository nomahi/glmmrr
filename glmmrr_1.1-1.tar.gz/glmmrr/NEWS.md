# glmmrr 1.1-1 (2025-01-10)

- first version released on GitHub
