scoef <- function(x, eform=FALSE, conf.level=0.95, digit=3){

	e1 <- x$coefficients
	s1 <- x$coef.sd
	c1 <- 1 - 0.5*(1 - conf.level)

	cl <- e1 - qnorm(c1)*s1
	cu <- e1 + qnorm(c1)*s1

	P1 <- 2*pnorm(-abs(e1)/s1)
	
	if(eform==FALSE){
	
		R1 <- data.frame(e1,s1,cl,cu,P1)
		R1 <- round(R1,digit)
		colnames(R1) <- c("coef","se","CL","CU","Pr(>|z|)")
	
	}

	if(eform==TRUE){
	
		R1 <- data.frame(exp(e1),s1,exp(cl),exp(cu),P1)
		R1 <- round(R1,digit)
		colnames(R1) <- c("exp(coef)","se","exp(CL)","exp(CU)","Pr(>|z|)")
	
	}

	return(R1)

}
