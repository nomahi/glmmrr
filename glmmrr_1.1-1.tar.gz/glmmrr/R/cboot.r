cboot <- function(cluster, data=NULL){

	data <- data.frame(data)
	id <- data[, deparse(substitute(cluster))]
	
	ID <- unique(id)
	n <- length(ID)

	IDb <- sample(ID,n,replace=TRUE)
	
	bdata <- idb <- NULL
	
	for(i in 1:n){
	
		wi <- which(id==IDb[i])
		bdata <- rbind(bdata,data[wi,])
		idb <- c(idb,rep(i,times=length(wi)))

	}
	
	bdata$cluster.b <- idb
	
	return(bdata)

}
